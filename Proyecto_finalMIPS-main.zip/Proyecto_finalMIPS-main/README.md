El proyecto consiste en el desarrollo de un pipeline MIPS de 5 etapas, junto con un decodificador de instrucciones en Python capaz de traducir un conjunto extendido de instrucciones MIPS a su representación binaria. Dicho binario será utilizado para precargar la memoria de instrucciones del procesador diseñado en Verilog.
Consistió en el desarrollo de 5 etapas (IF, ID, EX, MEM, WB), implementado 
en lenguaje verilog acompañado de su decodificador Python con interfaz 
gráfica para que sea de forma más fácil de usar por el usuario.
 
